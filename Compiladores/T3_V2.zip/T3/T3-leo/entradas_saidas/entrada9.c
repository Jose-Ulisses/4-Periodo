def func(float b) {
	if(b <= 3 || !1)
		code;
	otherwise{
		this_thing = for();
	}
}
