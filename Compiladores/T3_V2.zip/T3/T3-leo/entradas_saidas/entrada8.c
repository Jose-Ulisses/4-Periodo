void main() {
	int x,y;
	while(y > 10) {
		return k;
	}
}
